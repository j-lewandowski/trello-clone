const OrganizationIdPage = () => {
  return (
    <div>
      Organization Page
    </div>
  );
};

export default OrganizationIdPage;
